<html>
<head>
    <title>Lab 4</title>
</head>
<body>
<?php

    echo "<h3>Email regex</h3>";

    $email_regex = "/^[0-9a-z]+[-\._0-9a-z]*@[0-9a-z]+[-\._^0-9a-z]*[0-9a-z]+[\.]{1}[a-z]{2,6}$/";

    $email_list = array("vasya-pupkin@mail.com", "vasya_pupkin@mail.com", "vasya.pupkin@mail.com",
        "v.v.pupkin@firma.mail.com", "v.v.pupkin@firma-mail.com", "v.v.pupkin12@firma_mail.com",
        "v.v.pupkin-director@firma.mail.com", "-vasya--pupkin@mail.com", "vasya_pupkin@mail..com",
        "v.v.pup kin@firma.mail.com", "v.v.pup#kin@firma-mail.com_");

    foreach ($email_list as $email) {
        echo "$email is " . (preg_match($email_regex, $email) ? "valid" : "invalid") . "<br>";
    }

    echo "<h3>HTML comments regex</h3>";

    $html_comments_regex = "/<!--[^>]*-->/";

    $html = "
    <!-- This is a comment -->
    <p>This is a paragraph.</p>
    <!-- Remember to add more information here -->
    <!--[if IE]>
        <link href='/css/invstroyIEfix.css' rel='stylesheet' type='text/css' />
    <![endif]-->";

    echo htmlspecialchars(preg_replace('/<!--[^>]*-->/', "", $html));

    echo "<h3>HTML tags regex</h3>";

    $html = "
    <tr>
        <td align='center' width='80%' bgcolor='#0400b0' class='bottomline'>
        &copy; 2007-2008, �������� �����.<br />
        ���. 111-22-33, �����: ��. �����-����-��, ���.999
        </td>
    </tr>";

    echo preg_replace("/<[^>]*>/", "", $html);

    echo "<h3>5+ letter words regex</h3>";

    $text = "THIS IS JOHN SMITH. HE�S COLOMBIAN BUT HE LIVES IN BRAZIL. HE IS A PRISONER. MR SMITH IS 33 YEARS OLD.
        HE DOESN�T WORK OR STUDY. MR SMITH CANNOT READ OR WRITE BUT HE CAN PLAY THE GUITAR VERY WELL.
        HE PLAYS THE GUITAR EVERY DAY AT 6:30 PM AFTER DINNER. THE OTHER PRISONERS ALL LIKE HIS MUSIC.
        MR SMITH LIKES POP ROCK BUT HE DOESN�T LIKE SAMBA.";

    echo preg_replace("/([A-Z]{5,})/", "<span style='color:red'>$1</span>", $text);

?>
</body>
</html>